import { db } from "./db";
import { cards, type InsertCard, type UpdateCardRequest, type Card } from "@shared/schema";
import { eq } from "drizzle-orm";
import { randomBytes } from "crypto";

export interface IStorage {
  createCard(card: InsertCard): Promise<Card>;
  getCardByPublicId(publicId: string): Promise<Card | undefined>;
  updateCard(publicId: string, updates: UpdateCardRequest): Promise<Card | undefined>;
}

export class DatabaseStorage implements IStorage {
  async createCard(insertCard: InsertCard): Promise<Card> {
    const publicId = randomBytes(4).toString('hex'); // 8 char unique ID
    const editToken = randomBytes(16).toString('hex'); // Secret token
    
    const [card] = await db.insert(cards).values({
      ...insertCard,
      publicId,
      editToken
    }).returning();
    
    return card;
  }

  async getCardByPublicId(publicId: string): Promise<Card | undefined> {
    const [card] = await db.select().from(cards).where(eq(cards.publicId, publicId));
    return card;
  }

  async updateCard(publicId: string, updates: UpdateCardRequest): Promise<Card | undefined> {
    // Verify token matches in route handler, here we just update by publicId
    // But we need to make sure we don't overwrite the ID or token if they aren't meant to change
    // The UpdateCardRequest includes editToken for verification, but we shouldn't update it in DB typically
    // unless requested. For now, we exclude editToken from the set.
    
    const { editToken, ...dataToUpdate } = updates;
    
    const [updated] = await db.update(cards)
      .set(dataToUpdate)
      .where(eq(cards.publicId, publicId))
      .returning();
      
    return updated;
  }
}

export const storage = new DatabaseStorage();
