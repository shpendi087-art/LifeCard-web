## Packages
react-qr-code | To generate the QR code for sharing the emergency card
framer-motion | For smooth page transitions and entry animations
lucide-react | For high-quality icons (phone, medical, alert)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  sans: ["var(--font-sans)"],
}
