import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertCardSchema, type InsertCard } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Loader2, Save } from "lucide-react";
import { motion } from "framer-motion";

interface Props {
  defaultValues?: Partial<InsertCard>;
  onSubmit: (data: InsertCard) => void;
  isPending: boolean;
  mode?: "create" | "edit";
}

const BLOOD_TYPES = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-", "Unknown"];

export function CardForm({ defaultValues, onSubmit, isPending, mode = "create" }: Props) {
  const form = useForm<InsertCard>({
    resolver: zodResolver(insertCardSchema),
    defaultValues: {
      fullName: "",
      bloodType: "",
      allergies: "",
      medicalNotes: "",
      address: "",
      contacts: [],
      ...defaultValues,
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "contacts",
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <div className="space-y-6 bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
          <div className="border-b pb-4 mb-4">
            <h3 className="text-lg font-semibold text-slate-800">Personal Information</h3>
            <p className="text-sm text-muted-foreground">This information will be visible to emergency responders.</p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <FormField
              control={form.control}
              name="fullName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Jane Doe" {...field} className="h-12 bg-slate-50 border-slate-200" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="bloodType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Blood Type</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value || undefined}>
                    <FormControl>
                      <SelectTrigger className="h-12 bg-slate-50 border-slate-200">
                        <SelectValue placeholder="Select blood type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {BLOOD_TYPES.map((type) => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="address"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Home Address</FormLabel>
                <FormControl>
                  <Input placeholder="123 Main St, City, Country" {...field} value={field.value || ""} className="h-12 bg-slate-50 border-slate-200" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid gap-6 md:grid-cols-2">
            <FormField
              control={form.control}
              name="allergies"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Allergies</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Peanuts, Penicillin, Latex..." 
                      className="min-h-[100px] bg-slate-50 border-slate-200 resize-none" 
                      {...field} 
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="medicalNotes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Medical Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Diabetes, pacemaker, current medications..." 
                      className="min-h-[100px] bg-slate-50 border-slate-200 resize-none" 
                      {...field} 
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>

        <div className="space-y-6 bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
          <div className="border-b pb-4 mb-4 flex justify-between items-center">
            <div>
              <h3 className="text-lg font-semibold text-slate-800">Emergency Contacts</h3>
              <p className="text-sm text-muted-foreground">People to call in an emergency.</p>
            </div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => append({ name: "", phone: "", relation: "" })}
              className="gap-2"
            >
              <Plus className="w-4 h-4" /> Add Contact
            </Button>
          </div>

          <div className="space-y-4">
            {fields.map((field, index) => (
              <motion.div 
                key={field.id}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="grid gap-4 md:grid-cols-3 items-start bg-slate-50/50 p-4 rounded-xl border border-slate-100 relative group"
              >
                <FormField
                  control={form.control}
                  name={`contacts.${index}.name`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs uppercase text-slate-500 font-bold">Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Name" {...field} className="bg-white" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name={`contacts.${index}.relation`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs uppercase text-slate-500 font-bold">Relation</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Mother, Spouse" {...field} className="bg-white" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex gap-2 items-start">
                  <FormField
                    control={form.control}
                    name={`contacts.${index}.phone`}
                    render={({ field }) => (
                      <FormItem className="flex-1">
                        <FormLabel className="text-xs uppercase text-slate-500 font-bold">Phone</FormLabel>
                        <FormControl>
                          <Input placeholder="+1 234 567 8900" {...field} className="bg-white" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="mt-8 text-slate-400 hover:text-red-500 hover:bg-red-50"
                    onClick={() => remove(index)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </motion.div>
            ))}

            {fields.length === 0 && (
              <div className="text-center py-8 text-muted-foreground bg-slate-50 rounded-xl border border-dashed">
                No contacts added yet.
              </div>
            )}
          </div>
        </div>

        <Button 
          type="submit" 
          disabled={isPending}
          className="w-full h-14 text-lg font-semibold shadow-lg shadow-primary/25 rounded-xl hover:-translate-y-0.5 transition-all"
        >
          {isPending ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="mr-2 h-5 w-5" />
              {mode === 'create' ? 'Create LifeCard' : 'Save Changes'}
            </>
          )}
        </Button>
      </form>
    </Form>
  );
}
