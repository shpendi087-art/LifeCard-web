import { useEffect, useState } from "react";
import { useLocation, useRoute } from "wouter";
import { CardForm } from "@/components/CreateCardForm";
import { useCard, useUpdateCard } from "@/hooks/use-cards";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { AlertCircle, ArrowLeft, Eye, Link2, Check, QrCode } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import QRCode from "react-qr-code";

export default function Edit() {
  const [match, params] = useRoute("/e/:publicId");
  const publicId = params?.publicId!;
  const { data: card, isLoading, error } = useCard(publicId);
  const { mutate: updateCard, isPending } = useUpdateCard();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  // Auth state
  const [token, setToken] = useState<string>("");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  // UI state
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);
  const [copied, setCopied] = useState(false);

  // Check for existing token on mount
  useEffect(() => {
    const storedToken = localStorage.getItem(`lifecard_token_${publicId}`);
    
    // Check URL query param for first time creation
    const searchParams = new URLSearchParams(window.location.search);
    const isFirstTime = searchParams.get('first_time') === 'true';

    if (storedToken) {
      setToken(storedToken);
      setIsAuthenticated(true);
      if (isFirstTime) {
        setShowSuccessModal(true);
        // Clean up URL
        window.history.replaceState({}, '', `/e/${publicId}`);
      }
    }
  }, [publicId]);

  const handleAuth = () => {
    if (token.trim().length > 0) {
      localStorage.setItem(`lifecard_token_${publicId}`, token);
      setIsAuthenticated(true);
    }
  };

  const handleSubmit = (data: any) => {
    updateCard({ publicId, editToken: token, ...data }, {
      onSuccess: () => {
        toast({
          title: "Changes saved",
          description: "Your LifeCard has been updated successfully.",
        });
      },
      onError: (err) => {
        toast({
          title: "Failed to save",
          description: err.message,
          variant: "destructive",
        });
      }
    });
  };

  const copyLink = () => {
    const url = `${window.location.origin}/c/${publicId}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center">
          <div className="w-12 h-12 bg-slate-200 rounded-full mb-4"></div>
          <div className="h-4 w-32 bg-slate-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (error || !card) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Alert variant="destructive" className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>Could not load card. It may not exist.</AlertDescription>
        </Alert>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full border border-slate-100">
          <h2 className="text-2xl font-bold mb-2">Enter Access Token</h2>
          <p className="text-slate-600 mb-6">You need the edit token to modify this LifeCard.</p>
          <div className="space-y-4">
            <Input 
              placeholder="Paste your token here..." 
              value={token} 
              onChange={(e) => setToken(e.target.value)}
              className="text-lg"
            />
            <Button onClick={handleAuth} className="w-full h-12 text-lg">
              Unlock Editing
            </Button>
            <div className="text-center">
              <Button variant="link" onClick={() => setLocation(`/c/${publicId}`)}>
                Just view the card instead
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50/50 pb-20">
      {/* Header */}
      <div className="bg-white border-b border-slate-100 sticky top-0 z-30">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => setLocation("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="font-bold text-lg hidden sm:block">Editing LifeCard</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowQRModal(true)}>
              <QrCode className="w-4 h-4 mr-2" /> Show QR
            </Button>
            <Button variant="default" size="sm" onClick={() => setLocation(`/c/${publicId}`)}>
              <Eye className="w-4 h-4 mr-2" /> View Public
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-8">
        <CardForm 
          defaultValues={card} 
          onSubmit={handleSubmit} 
          isPending={isPending} 
          mode="edit" 
        />
        
        <div className="mt-8 p-6 bg-yellow-50 rounded-xl border border-yellow-100">
          <h3 className="font-bold text-yellow-900 mb-2">Save your Edit Token!</h3>
          <p className="text-yellow-800 text-sm mb-4">
            You will need this token to edit this card in the future on other devices.
          </p>
          <div className="flex gap-2">
            <code className="flex-1 p-3 bg-white rounded border border-yellow-200 text-sm font-mono overflow-x-auto">
              {token}
            </code>
            <Button variant="outline" onClick={() => {
              navigator.clipboard.writeText(token);
              toast({ title: "Token copied!" });
            }}>
              Copy
            </Button>
          </div>
        </div>
      </div>

      {/* Success Modal (First Time) */}
      <Dialog open={showSuccessModal} onOpenChange={setShowSuccessModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl">Card Created! 🎉</DialogTitle>
            <DialogDescription className="text-center pt-2">
              Your LifeCard is ready. Save this link or QR code to share it.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col items-center py-6 gap-6">
            <div className="bg-white p-4 rounded-xl shadow-lg border-2 border-slate-100">
              <QRCode value={`${window.location.origin}/c/${publicId}`} size={180} />
            </div>
            <div className="w-full flex gap-2">
              <Input value={`${window.location.origin}/c/${publicId}`} readOnly />
              <Button size="icon" variant="outline" onClick={copyLink}>
                {copied ? <Check className="w-4 h-4 text-green-600" /> : <Link2 className="w-4 h-4" />}
              </Button>
            </div>
          </div>
          <DialogFooter className="sm:justify-center">
            <Button onClick={() => setShowSuccessModal(false)} className="w-full">
              Continue Editing
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* QR Code Modal (Always accessible) */}
      <Dialog open={showQRModal} onOpenChange={setShowQRModal}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-center">Your LifeCard QR</DialogTitle>
          </DialogHeader>
          <div className="flex justify-center py-6">
            <div className="bg-white p-4 rounded-xl shadow-lg border-2 border-slate-100">
              <QRCode value={`${window.location.origin}/c/${publicId}`} size={200} />
            </div>
          </div>
          <div className="text-center text-sm text-muted-foreground">
            Scan to view emergency info
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
