import { useCard } from "@/hooks/use-cards";
import { useRoute } from "wouter";
import { Phone, MapPin, AlertTriangle, FileText, Droplets, User, QrCode } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useState } from "react";
import QRCode from "react-qr-code";

export default function ViewCard() {
  const [match, params] = useRoute("/c/:publicId");
  const publicId = params?.publicId!;
  const { data: card, isLoading, error } = useCard(publicId);
  const [showQR, setShowQR] = useState(false);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <div className="w-16 h-16 border-4 border-red-500 border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-slate-500 font-medium animate-pulse">Loading Emergency Info...</p>
      </div>
    );
  }

  if (error || !card) {
    return (
      <div className="min-h-screen bg-red-50 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full text-center">
          <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Card Not Found</h2>
          <p className="text-slate-600">The emergency card you are looking for does not exist or has been deleted.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 pb-12">
      {/* Emergency Header - RED for high visibility */}
      <div className="bg-red-600 text-white p-6 pb-12 shadow-md relative overflow-hidden">
        <div className="max-w-md mx-auto relative z-10">
          <div className="flex justify-between items-start mb-4">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur px-3 py-1 rounded-full text-sm font-semibold border border-white/20">
              <AlertTriangle className="w-4 h-4" /> Emergency Card
            </div>
            <button onClick={() => setShowQR(true)} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors">
              <QrCode className="w-5 h-5" />
            </button>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-1">{card.fullName}</h1>
          <div className="flex items-center gap-2 text-red-100 font-medium">
            <User className="w-4 h-4" /> ID: {card.publicId}
          </div>
        </div>

        {/* Decorative background */}
        <div className="absolute right-[-20%] top-[-20%] w-64 h-64 bg-red-500 rounded-full opacity-50 blur-3xl"></div>
      </div>

      <div className="max-w-md mx-auto px-4 -mt-8 space-y-4 relative z-20">
        
        {/* Critical Medical Info Cards */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200/60">
            <div className="flex items-center gap-2 text-slate-500 mb-2 font-medium text-xs uppercase tracking-wider">
              <Droplets className="w-4 h-4 text-red-500" /> Blood Type
            </div>
            <div className="text-2xl font-bold text-slate-900">
              {card.bloodType || "N/A"}
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200/60">
            <div className="flex items-center gap-2 text-slate-500 mb-2 font-medium text-xs uppercase tracking-wider">
              <AlertTriangle className="w-4 h-4 text-amber-500" /> Allergies
            </div>
            <div className="text-lg font-bold text-slate-900 line-clamp-2 leading-tight">
              {card.allergies || "None listed"}
            </div>
          </div>
        </div>

        {/* Emergency Contacts - Priority #1 */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="bg-slate-50 px-4 py-3 border-b border-slate-100 flex items-center gap-2">
            <Phone className="w-4 h-4 text-slate-500" />
            <h3 className="font-semibold text-slate-900">Emergency Contacts</h3>
          </div>
          <div className="divide-y divide-slate-100">
            {card.contacts && card.contacts.length > 0 ? (
              card.contacts.map((contact, idx) => (
                <div key={idx} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div>
                    <div className="font-bold text-slate-900">{contact.name}</div>
                    <div className="text-sm text-slate-500 font-medium">{contact.relation}</div>
                  </div>
                  <a href={`tel:${contact.phone}`}>
                    <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white rounded-full px-4 shadow-md shadow-green-200">
                      <Phone className="w-4 h-4 mr-1.5" /> Call
                    </Button>
                  </a>
                </div>
              ))
            ) : (
              <div className="p-6 text-center text-slate-500 italic">No contacts listed</div>
            )}
          </div>
        </div>

        {/* Medical Notes */}
        {card.medicalNotes && (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
            <div className="flex items-center gap-2 text-slate-500 mb-3 font-medium text-xs uppercase tracking-wider">
              <FileText className="w-4 h-4 text-blue-500" /> Medical Notes
            </div>
            <p className="text-slate-800 leading-relaxed whitespace-pre-wrap">
              {card.medicalNotes}
            </p>
          </div>
        )}

        {/* Address */}
        {card.address && (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
            <div className="flex items-center gap-2 text-slate-500 mb-3 font-medium text-xs uppercase tracking-wider">
              <MapPin className="w-4 h-4 text-purple-500" /> Home Address
            </div>
            <p className="text-slate-800 font-medium">
              {card.address}
            </p>
          </div>
        )}

        {/* Footer info */}
        <div className="pt-8 text-center">
          <p className="text-xs text-slate-400 mb-2">Powered by LifeCard</p>
          <a href="/" className="text-sm font-medium text-primary hover:underline">
            Create your own free emergency card
          </a>
        </div>
      </div>

      {/* QR Code Modal for sharing by responders */}
      <Dialog open={showQR} onOpenChange={setShowQR}>
        <DialogContent className="sm:max-w-xs flex flex-col items-center justify-center">
          <div className="bg-white p-4 rounded-xl shadow-none">
            <QRCode value={window.location.href} size={200} />
          </div>
          <p className="text-center text-sm font-medium text-slate-600">
            Scan to share this information
          </p>
        </DialogContent>
      </Dialog>
    </div>
  );
}
