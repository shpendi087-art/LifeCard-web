import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Shield, Smartphone, Heart, Lock, User, QrCode } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="border-b border-slate-100 bg-white/80 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white font-bold">
              <Heart className="w-5 h-5 fill-current" />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900">LifeCard</span>
          </div>
          <Link href="/create">
            <Button className="font-semibold shadow-md shadow-primary/20">
              Create My Card
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-16 pb-24 lg:pt-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-50 text-red-600 text-sm font-medium mb-8">
            <Shield className="w-4 h-4" /> Free, Private, and Offline-First
          </div>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-slate-900 mb-6 text-balance">
            Help others help you <br className="hidden md:block"/>
            <span className="text-primary">when it matters most.</span>
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-10 text-balance">
            Create a secure emergency medical card that works on any phone. No app install required for first responders.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link href="/create">
              <Button size="lg" className="h-14 px-8 text-lg font-semibold rounded-full shadow-xl shadow-primary/20 hover:scale-105 transition-transform">
                Create Your Free Card
              </Button>
            </Link>
            <Button variant="outline" size="lg" className="h-14 px-8 text-lg rounded-full border-2">
              How it Works
            </Button>
          </div>
        </div>

        {/* Decorative background blobs */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 overflow-hidden opacity-30 pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-red-200 rounded-full blur-3xl mix-blend-multiply animate-blob"></div>
          <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-blue-100 rounded-full blur-3xl mix-blend-multiply animate-blob animation-delay-2000"></div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-red-50 text-red-600 rounded-xl flex items-center justify-center mb-6">
                <QrCode className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Instant Access</h3>
              <p className="text-slate-600">
                First responders can scan your QR code to instantly see your allergies, blood type, and contacts without unlocking your phone.
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center mb-6">
                <Smartphone className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Universal Compatibility</h3>
              <p className="text-slate-600">
                Works on any smartphone (iPhone, Android) and computer. No specialized hardware or app installation needed.
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-green-50 text-green-600 rounded-xl flex items-center justify-center mb-6">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Private & Secure</h3>
              <p className="text-slate-600">
                You control what information is shown. No tracking, no ads, and your data stays yours. Edit anytime with a secure link.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-100 py-12">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-500">
          <p>© 2024 LifeCard. Essential information when seconds count.</p>
        </div>
      </footer>
    </div>
  );
}
