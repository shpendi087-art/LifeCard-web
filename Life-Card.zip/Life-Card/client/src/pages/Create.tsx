import { CardForm } from "@/components/CreateCardForm";
import { useCreateCard } from "@/hooks/use-cards";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function Create() {
  const { mutate, isPending } = useCreateCard();
  const { toast } = useToast();

  const handleSubmit = (data: any) => {
    mutate(data, {
      onError: (err) => {
        toast({
          title: "Error creating card",
          description: err.message,
          variant: "destructive",
        });
      },
    });
  };

  return (
    <div className="min-h-screen bg-slate-50/50">
      <div className="max-w-3xl mx-auto px-4 py-8 sm:py-12">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-sm font-medium text-slate-500 hover:text-slate-900 mb-6 transition-colors">
            <ArrowLeft className="w-4 h-4 mr-1" /> Back to Home
          </Link>
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">Create Your LifeCard</h1>
          <p className="text-lg text-slate-600">Fill in the details you want emergency responders to see.</p>
        </div>

        <CardForm onSubmit={handleSubmit} isPending={isPending} />
      </div>
    </div>
  );
}
