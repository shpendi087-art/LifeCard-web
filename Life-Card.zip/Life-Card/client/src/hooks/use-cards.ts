import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertCard, type UpdateCardRequest } from "@shared/routes";
import { useLocation } from "wouter";

export function useCard(publicId: string) {
  return useQuery({
    queryKey: [api.cards.get.path, publicId],
    queryFn: async () => {
      const url = buildUrl(api.cards.get.path, { publicId });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch card");
      return api.cards.get.responses[200].parse(await res.json());
    },
    enabled: !!publicId,
  });
}

export function useCreateCard() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: InsertCard) => {
      const res = await fetch(api.cards.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.cards.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to create card");
      }

      return api.cards.create.responses[201].parse(await res.json());
    },
    onSuccess: (data) => {
      // Store edit token securely
      localStorage.setItem(`lifecard_token_${data.publicId}`, data.editToken);
      // Redirect to edit page
      setLocation(`/e/${data.publicId}?first_time=true`);
    },
  });
}

export function useUpdateCard() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ publicId, ...data }: UpdateCardRequest & { publicId: string }) => {
      const url = buildUrl(api.cards.update.path, { publicId });
      const res = await fetch(url, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        if (res.status === 400) throw new Error("Validation failed");
        if (res.status === 403) throw new Error("Invalid edit token");
        if (res.status === 404) throw new Error("Card not found");
        throw new Error("Failed to update card");
      }

      return api.cards.update.responses[200].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.cards.get.path, variables.publicId] });
    },
  });
}
