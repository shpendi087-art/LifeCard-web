import { pgTable, text, serial, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const cards = pgTable("cards", {
  id: serial("id").primaryKey(),
  publicId: text("public_id").notNull().unique(),
  editToken: text("edit_token").notNull(),
  fullName: text("full_name").notNull(),
  bloodType: text("blood_type"),
  allergies: text("allergies"),
  medicalNotes: text("medical_notes"),
  address: text("address"),
  contacts: jsonb("contacts").$type<{name: string, phone: string, relation: string}[]>().notNull().default([]),
});

export const insertCardSchema = createInsertSchema(cards).omit({ 
  id: true,
  publicId: true, // Generated on server
  editToken: true // Generated on server
});

export type Card = typeof cards.$inferSelect;
export type InsertCard = z.infer<typeof insertCardSchema>;

export type CreateCardRequest = InsertCard;
export type UpdateCardRequest = Partial<InsertCard> & { editToken: string };

export type Contact = {
  name: string;
  phone: string;
  relation: string;
};
