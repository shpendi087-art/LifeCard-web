import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Linking,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import {
  Heart,
  Phone,
  MapPin,
  AlertCircle,
  Mail,
  Shield,
} from "lucide-react-native";
import { router } from "expo-router";

export default function HomeScreen() {
  const insets = useSafeAreaInsets();

  const openPrivacyPolicy = () => {
    // TODO: Update with your actual privacy policy URL
    Linking.openURL("https://yourapp.com/privacy-policy");
  };

  const openSupport = () => {
    // TODO: Update with your actual support email
    Linking.openURL("mailto:shpendi087@icloud.com");
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#fff" }}>
      <StatusBar style="dark" />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 20,
            paddingHorizontal: 20,
            paddingBottom: 30,
            backgroundColor: "#EF4444",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 8,
            }}
          >
            <Heart size={32} color="#fff" fill="#fff" />
            <Text
              style={{
                fontSize: 32,
                fontWeight: "bold",
                color: "#fff",
                marginLeft: 12,
              }}
            >
              LifeCard
            </Text>
          </View>
          <Text style={{ fontSize: 16, color: "#fff", opacity: 0.95 }}>
            Emergency information when it matters most
          </Text>
        </View>

        {/* Main Content */}
        <View style={{ padding: 20 }}>
          {/* Quick Actions */}
          <View style={{ marginBottom: 30 }}>
            <Text
              style={{
                fontSize: 20,
                fontWeight: "600",
                marginBottom: 16,
                color: "#111",
              }}
            >
              Quick Actions
            </Text>

            <TouchableOpacity
              onPress={() => router.push("/setup")}
              style={{
                backgroundColor: "#EF4444",
                padding: 20,
                borderRadius: 16,
                marginBottom: 12,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 8,
                elevation: 3,
              }}
            >
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <AlertCircle size={24} color="#fff" />
                <Text
                  style={{
                    fontSize: 18,
                    fontWeight: "600",
                    color: "#fff",
                    marginLeft: 12,
                    flex: 1,
                  }}
                >
                  Set Up Emergency Card
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={{
                backgroundColor: "#fff",
                padding: 20,
                borderRadius: 16,
                borderWidth: 2,
                borderColor: "#E5E7EB",
              }}
            >
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <Phone size={24} color="#111" />
                <Text
                  style={{
                    fontSize: 18,
                    fontWeight: "600",
                    color: "#111",
                    marginLeft: 12,
                    flex: 1,
                  }}
                >
                  View My Card
                </Text>
              </View>
            </TouchableOpacity>
          </View>

          {/* Features */}
          <View>
            <Text
              style={{
                fontSize: 20,
                fontWeight: "600",
                marginBottom: 16,
                color: "#111",
              }}
            >
              Why LifeCard?
            </Text>

            <FeatureItem
              icon={<Phone size={20} color="#EF4444" />}
              title="Instant Access"
              description="Anyone can access your info via QR code - no app needed"
            />
            <FeatureItem
              icon={<Heart size={20} color="#EF4444" />}
              title="Medical Info"
              description="Blood type, allergies, medications, and conditions"
            />
            <FeatureItem
              icon={<MapPin size={20} color="#EF4444" />}
              title="Emergency Contacts"
              description="Quick access to call your loved ones"
            />
            <FeatureItem
              icon={<AlertCircle size={20} color="#EF4444" />}
              title="Privacy First"
              description="You control what information is visible"
            />
          </View>

          {/* Privacy & Support Section */}
          <View
            style={{
              marginTop: 30,
              paddingTop: 30,
              borderTopWidth: 1,
              borderTopColor: "#E5E7EB",
            }}
          >
            <Text
              style={{
                fontSize: 20,
                fontWeight: "600",
                marginBottom: 16,
                color: "#111",
              }}
            >
              Privacy & Support
            </Text>

            <TouchableOpacity
              onPress={openPrivacyPolicy}
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: "#F9FAFB",
                padding: 16,
                borderRadius: 12,
                marginBottom: 12,
              }}
            >
              <View
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: "#FEE2E2",
                  alignItems: "center",
                  justifyContent: "center",
                  marginRight: 12,
                }}
              >
                <Shield size={20} color="#EF4444" />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{ fontSize: 16, fontWeight: "600", color: "#111" }}
                >
                  Privacy Policy
                </Text>
                <Text style={{ fontSize: 14, color: "#6B7280", marginTop: 2 }}>
                  Learn how we protect your data
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={openSupport}
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: "#F9FAFB",
                padding: 16,
                borderRadius: 12,
              }}
            >
              <View
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: "#FEE2E2",
                  alignItems: "center",
                  justifyContent: "center",
                  marginRight: 12,
                }}
              >
                <Mail size={20} color="#EF4444" />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{ fontSize: 16, fontWeight: "600", color: "#111" }}
                >
                  Contact Support
                </Text>
                <Text style={{ fontSize: 14, color: "#6B7280", marginTop: 2 }}>
                  Get help or ask questions
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

function FeatureItem({ icon, title, description }) {
  return (
    <View
      style={{
        flexDirection: "row",
        marginBottom: 20,
        alignItems: "flex-start",
      }}
    >
      <View
        style={{
          width: 40,
          height: 40,
          borderRadius: 20,
          backgroundColor: "#FEE2E2",
          alignItems: "center",
          justifyContent: "center",
          marginRight: 12,
        }}
      >
        {icon}
      </View>
      <View style={{ flex: 1 }}>
        <Text
          style={{
            fontSize: 16,
            fontWeight: "600",
            color: "#111",
            marginBottom: 4,
          }}
        >
          {title}
        </Text>
        <Text style={{ fontSize: 14, color: "#6B7280", lineHeight: 20 }}>
          {description}
        </Text>
      </View>
    </View>
  );
}
