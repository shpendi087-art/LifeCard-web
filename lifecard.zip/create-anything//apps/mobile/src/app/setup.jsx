import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Switch,
  Linking,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { ArrowLeft, Heart, Plus, X, AlertCircle } from "lucide-react-native";
import { router } from "expo-router";
import { useState } from "react";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";

export default function SetupScreen() {
  const insets = useSafeAreaInsets();

  const [fullName, setFullName] = useState("");
  const [bloodType, setBloodType] = useState("");
  const [allergies, setAllergies] = useState("");
  const [medicalNotes, setMedicalNotes] = useState("");
  const [homeAddress, setHomeAddress] = useState("");
  const [showAddress, setShowAddress] = useState(true);
  const [showMedicalNotes, setShowMedicalNotes] = useState(true);
  const [showBloodType, setShowBloodType] = useState(true);
  const [showAllergies, setShowAllergies] = useState(true);
  const [contacts, setContacts] = useState([
    { name: "", relationship: "", phone: "" },
  ]);

  // Consent states
  const [dataCollectionConsent, setDataCollectionConsent] = useState(false);
  const [qrSharingConsent, setQrSharingConsent] = useState(false);
  const [healthDataConsent, setHealthDataConsent] = useState(false);

  const addContact = () => {
    setContacts([...contacts, { name: "", relationship: "", phone: "" }]);
  };

  const removeContact = (index) => {
    setContacts(contacts.filter((_, i) => i !== index));
  };

  const updateContact = (index, field, value) => {
    const newContacts = [...contacts];
    newContacts[index][field] = value;
    setContacts(newContacts);
  };

  const handleSave = async () => {
    if (!dataCollectionConsent || !qrSharingConsent || !healthDataConsent) {
      alert("Please review and accept all consent agreements to continue.");
      return;
    }
    // TODO: Save to backend
    console.log("Saving emergency card...");
    router.back();
  };

  const openPrivacyPolicy = () => {
    // TODO: Update with your actual privacy policy URL
    Linking.openURL("https://yourapp.com/privacy-policy");
  };

  return (
    <KeyboardAvoidingAnimatedView style={{ flex: 1 }} behavior="padding">
      <View style={{ flex: 1, backgroundColor: "#fff" }}>
        <StatusBar style="light" />

        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 12,
            paddingHorizontal: 20,
            paddingBottom: 16,
            backgroundColor: "#EF4444",
            borderBottomWidth: 1,
            borderBottomColor: "#DC2626",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 8,
            }}
          >
            <TouchableOpacity
              onPress={() => router.back()}
              style={{ marginRight: 12 }}
            >
              <ArrowLeft size={24} color="#fff" />
            </TouchableOpacity>
            <Heart size={28} color="#fff" fill="#fff" />
            <Text
              style={{
                fontSize: 24,
                fontWeight: "bold",
                color: "#fff",
                marginLeft: 10,
              }}
            >
              Emergency Card Setup
            </Text>
          </View>
          <Text
            style={{
              fontSize: 14,
              color: "#fff",
              opacity: 0.9,
              marginLeft: 48,
            }}
          >
            Fill in your emergency information
          </Text>
        </View>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingBottom: 20 }}
          showsVerticalScrollIndicator={false}
        >
          <View style={{ padding: 20 }}>
            {/* Consent Section */}
            <View
              style={{
                backgroundColor: "#FEF2F2",
                borderWidth: 1,
                borderColor: "#FCA5A5",
                borderRadius: 12,
                padding: 16,
                marginBottom: 24,
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginBottom: 12,
                }}
              >
                <AlertCircle size={20} color="#EF4444" />
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    color: "#991B1B",
                    marginLeft: 8,
                  }}
                >
                  Privacy & Consent
                </Text>
              </View>

              <Text
                style={{
                  fontSize: 14,
                  color: "#7F1D1D",
                  marginBottom: 16,
                  lineHeight: 20,
                }}
              >
                Before setting up your emergency card, please review and accept
                the following:
              </Text>

              <ConsentCheckbox
                label="I consent to the collection and storage of my personal and medical information for emergency purposes."
                value={dataCollectionConsent}
                onValueChange={setDataCollectionConsent}
              />

              <ConsentCheckbox
                label="I understand that my emergency information will be accessible via a QR code to anyone who scans it, and I consent to sharing the information I choose to make visible."
                value={qrSharingConsent}
                onValueChange={setQrSharingConsent}
              />

              <ConsentCheckbox
                label="I consent to the collection of health-related data (blood type, allergies, medical notes) solely for emergency health management purposes."
                value={healthDataConsent}
                onValueChange={setHealthDataConsent}
              />

              <TouchableOpacity
                onPress={openPrivacyPolicy}
                style={{ marginTop: 12 }}
              >
                <Text
                  style={{
                    fontSize: 14,
                    color: "#DC2626",
                    textDecorationLine: "underline",
                    fontWeight: "600",
                  }}
                >
                  Read our Privacy Policy
                </Text>
              </TouchableOpacity>
            </View>

            {/* Personal Information */}
            <SectionHeader title="Personal Information" />

            <InputField
              label="Full Name"
              value={fullName}
              onChangeText={setFullName}
              placeholder="John Doe"
            />

            <InputField
              label="Blood Type"
              value={bloodType}
              onChangeText={setBloodType}
              placeholder="A+"
            />

            <InputField
              label="Allergies"
              value={allergies}
              onChangeText={setAllergies}
              placeholder="Penicillin, Peanuts, etc."
              multiline
            />

            <InputField
              label="Medical Notes"
              value={medicalNotes}
              onChangeText={setMedicalNotes}
              placeholder="Diabetes, Heart condition, etc."
              multiline
            />

            <InputField
              label="Home Address"
              value={homeAddress}
              onChangeText={setHomeAddress}
              placeholder="123 Main St, City, State"
              multiline
            />

            {/* Privacy Settings */}
            <SectionHeader
              title="QR Code Sharing Settings"
              style={{ marginTop: 24 }}
            />

            <Text
              style={{
                fontSize: 14,
                color: "#6B7280",
                marginBottom: 12,
                lineHeight: 20,
              }}
            >
              Control which information is visible when someone scans your QR
              code:
            </Text>

            <PrivacyToggle
              label="Show Blood Type"
              value={showBloodType}
              onValueChange={setShowBloodType}
            />

            <PrivacyToggle
              label="Show Allergies"
              value={showAllergies}
              onValueChange={setShowAllergies}
            />

            <PrivacyToggle
              label="Show Medical Notes"
              value={showMedicalNotes}
              onValueChange={setShowMedicalNotes}
            />

            <PrivacyToggle
              label="Show Home Address"
              value={showAddress}
              onValueChange={setShowAddress}
            />

            {/* Emergency Contacts */}
            <SectionHeader
              title="Emergency Contacts"
              style={{ marginTop: 24 }}
            />

            {contacts.map((contact, index) => (
              <View key={index} style={{ marginBottom: 16 }}>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginBottom: 8,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      fontWeight: "600",
                      color: "#6B7280",
                    }}
                  >
                    Contact {index + 1}
                  </Text>
                  {contacts.length > 1 && (
                    <TouchableOpacity onPress={() => removeContact(index)}>
                      <X size={20} color="#EF4444" />
                    </TouchableOpacity>
                  )}
                </View>

                <InputField
                  label="Name"
                  value={contact.name}
                  onChangeText={(value) => updateContact(index, "name", value)}
                  placeholder="Jane Doe"
                  compact
                />

                <InputField
                  label="Relationship"
                  value={contact.relationship}
                  onChangeText={(value) =>
                    updateContact(index, "relationship", value)
                  }
                  placeholder="Spouse, Parent, etc."
                  compact
                />

                <InputField
                  label="Phone"
                  value={contact.phone}
                  onChangeText={(value) => updateContact(index, "phone", value)}
                  placeholder="(555) 123-4567"
                  keyboardType="phone-pad"
                  compact
                />
              </View>
            ))}

            <TouchableOpacity
              onPress={addContact}
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                padding: 12,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: "#E5E7EB",
                borderStyle: "dashed",
                marginTop: 8,
              }}
            >
              <Plus size={20} color="#6B7280" />
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "600",
                  color: "#6B7280",
                  marginLeft: 8,
                }}
              >
                Add Contact
              </Text>
            </TouchableOpacity>

            {/* Save Button */}
            <TouchableOpacity
              onPress={handleSave}
              style={{
                backgroundColor: "#EF4444",
                padding: 18,
                borderRadius: 16,
                alignItems: "center",
                marginTop: 32,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 8,
                elevation: 3,
                opacity:
                  dataCollectionConsent && qrSharingConsent && healthDataConsent
                    ? 1
                    : 0.5,
              }}
            >
              <Text style={{ fontSize: 18, fontWeight: "600", color: "#fff" }}>
                Save Emergency Card
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </KeyboardAvoidingAnimatedView>
  );
}

function ConsentCheckbox({ label, value, onValueChange }) {
  return (
    <TouchableOpacity
      onPress={() => onValueChange(!value)}
      style={{
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 12,
      }}
    >
      <View
        style={{
          width: 20,
          height: 20,
          borderRadius: 4,
          borderWidth: 2,
          borderColor: value ? "#EF4444" : "#D1D5DB",
          backgroundColor: value ? "#EF4444" : "#fff",
          alignItems: "center",
          justifyContent: "center",
          marginRight: 10,
          marginTop: 2,
        }}
      >
        {value && (
          <Text style={{ color: "#fff", fontSize: 14, fontWeight: "bold" }}>
            ✓
          </Text>
        )}
      </View>
      <Text style={{ flex: 1, fontSize: 14, color: "#7F1D1D", lineHeight: 20 }}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

function SectionHeader({ title, style }) {
  return (
    <Text
      style={[
        {
          fontSize: 18,
          fontWeight: "600",
          color: "#111",
          marginBottom: 12,
        },
        style,
      ]}
    >
      {title}
    </Text>
  );
}

function InputField({
  label,
  value,
  onChangeText,
  placeholder,
  multiline,
  keyboardType,
  compact,
}) {
  return (
    <View style={{ marginBottom: compact ? 8 : 16 }}>
      <Text
        style={{
          fontSize: 14,
          fontWeight: "600",
          color: "#374151",
          marginBottom: 6,
        }}
      >
        {label}
      </Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#9CA3AF"
        multiline={multiline}
        keyboardType={keyboardType}
        style={{
          backgroundColor: "#F9FAFB",
          borderWidth: 1,
          borderColor: "#E5E7EB",
          borderRadius: 12,
          padding: 14,
          fontSize: 16,
          color: "#111",
          minHeight: multiline ? 80 : 48,
        }}
      />
    </View>
  );
}

function PrivacyToggle({ label, value, onValueChange }) {
  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        backgroundColor: "#F9FAFB",
        padding: 16,
        borderRadius: 12,
        marginBottom: 12,
      }}
    >
      <Text style={{ fontSize: 16, fontWeight: "500", color: "#111" }}>
        {label}
      </Text>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: "#D1D5DB", true: "#FCA5A5" }}
        thumbColor={value ? "#EF4444" : "#F3F4F6"}
      />
    </View>
  );
}
